import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Font;

public class DemoApplication {

	private JFrame frame;
	private JTextField fileLocationName;
	private JTextField keyTextField;
	private JTextField valueTextField;
	private JButton btnDelete;
	private JButton btnGet;
	private JButton btnA;
	private JButton btnB;
	private JButton btnC;
	private JButton btnD;
	private JButton btnE;
	private JButton btnF;
	private JButton btnG;
	private JButton btnH;
	private JButton btnCreate;
	private ValueStore vs;
	private JTextArea textArea;
	private JLabel lblDirection;
	private JLabel label;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DemoApplication window = new DemoApplication();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DemoApplication() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1012, 617);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblKey = new JLabel("Key:");
		lblKey.setBounds(26, 86, 69, 20);
		frame.getContentPane().add(lblKey);
		
		JLabel lblValue = new JLabel("Value :");
		lblValue.setBounds(13, 128, 50, 20);
		frame.getContentPane().add(lblValue);
		
		JLabel lblEnterFileLocation = new JLabel("Enter File Location:");
		lblEnterFileLocation.setBounds(26, 45, 136, 20);
		frame.getContentPane().add(lblEnterFileLocation);
		
		fileLocationName = new JTextField();
		fileLocationName.setBounds(177, 42, 146, 26);
		frame.getContentPane().add(fileLocationName);
		fileLocationName.setColumns(10);
		
		keyTextField = new JTextField();
		keyTextField.setBounds(78, 83, 146, 26);
		frame.getContentPane().add(keyTextField);
		keyTextField.setColumns(10);
		
		valueTextField = new JTextField();
		valueTextField.setBounds(78, 125, 146, 26);
		frame.getContentPane().add(valueTextField);
		valueTextField.setColumns(100);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					vs.Put(Integer.parseInt(keyTextField.getText()), valueTextField.getText().getBytes());
					keyTextField.setText("");
					valueTextField.setText("");
				} catch (NumberFormatException ne) {
					// TODO Auto-generated catch block
					ne.printStackTrace();
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnInsert.setBounds(23, 170, 85, 29);
		frame.getContentPane().add(btnInsert);
		
		btnDelete = new JButton("Remove");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				vs.Remove(Integer.parseInt(keyTextField.getText()));
			}
		});
		btnDelete.setBounds(163, 170, 101, 29);
		frame.getContentPane().add(btnDelete);
		
		btnGet = new JButton("Get");
		btnGet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String data = new String(vs.Get(Integer.parseInt(keyTextField.getText())));
				System.out.println("Length of data = " + data.length());
				System.out.println("Data = " + data);
			}
		});
		btnGet.setBounds(324, 170, 69, 29);
		frame.getContentPane().add(btnGet);
		
		btnA = new JButton("A");
		btnA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("A");
				try {
					vs.Put(1, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnA.setBounds(15, 245, 80, 29);
		frame.getContentPane().add(btnA);
		
		btnB = new JButton("B");
		btnB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("B");
				try {
					vs.Put(2, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnB.setBounds(124, 245, 83, 29);
		frame.getContentPane().add(btnB);
		
		btnC = new JButton("C");
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("C");
				try {
					vs.Put(3, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnC.setBounds(223, 245, 85, 29);
		frame.getContentPane().add(btnC);
		
		btnD = new JButton("D");
		btnD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("D");
				try {
					vs.Put(4, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnD.setBounds(324, 245, 85, 29);
		frame.getContentPane().add(btnD);
		
		btnE = new JButton("E");
		btnE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("E");
				try {
					vs.Put(5, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnE.setBounds(13, 305, 82, 29);
		frame.getContentPane().add(btnE);
		
		btnF = new JButton("F");
		btnF.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("F");
				try {
					vs.Put(6, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnF.setBounds(124, 305, 83, 29);
		frame.getContentPane().add(btnF);
		
		btnG = new JButton("G");
		btnG.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("G");
				try {
					vs.Put(7, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnG.setBounds(223, 305, 85, 29);
		frame.getContentPane().add(btnG);
		
		btnH = new JButton("H");
		btnH.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				byte[] data = readFile("H");
				try {
					vs.Put(8, data);
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnH.setBounds(334, 305, 82, 29);
		frame.getContentPane().add(btnH);
		
		btnCreate = new JButton("Create");
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				vs = new ValueStore();
				try {
					vs.createDB(fileLocationName.getText());
					fileLocationName.setText("");
				} catch (IOException ie) {
					// TODO Auto-generated catch block
					ie.printStackTrace();
				}
			}
		});
		btnCreate.setBounds(330, 41, 79, 29);
		frame.getContentPane().add(btnCreate);
		
		JTextArea infotextArea = new JTextArea();
		infotextArea.setFont(new Font("Monospaced", Font.PLAIN, 15));
		infotextArea.setWrapStyleWord(true);
		infotextArea.setLineWrap(true);
		infotextArea.setEditable(false);
		infotextArea.setBounds(447, 43, 528, 355);
		infotextArea.setText("(1) Click on button A to insert contents of A.txt(size 1Mb) file. The key for A button is 1( predefined )\n (2) Click on button B to insert contents of B.txt(size 1Mb) file. The key for B button is 2( predefined )\n (3) Click on button C to insert contents of C.txt(size 1Mb) file. The key for C button is 3( predefined )\n (4) Click on button D to insert contents of D.txt(size 1Mb) file. The key for D button is 4( predefined )\n (5) Click on button E to insert contents of E.txt(size 1/2 Mb) file. The key for E button is 5( predefined )\n (6) Click on button F to insert contents of F.txt(size 1Mb) file. The key for F button is 6( predefined )\n (7) Click on button G to insert contents of G.txt(size 1Mb) file. The key for G button is 7(predefined)\n (8) Click on button H to insert contents of H.txt(size 1Mb) file. The key for H button is 8(predefined)");
		//infotextArea.
		frame.getContentPane().add(infotextArea);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 15));
		textArea.setBounds(26, 414, 921, 140);
		textArea.setText(" (1) Key must be an integer and must be greater than 1 \n (2) To remove the text entered by clicking on A, B, C, D etc button type there predefined key values \n in the key textfiled and click on remove button. \n (3) To enter (key, value) manually enter them in the key textfield and value textfield. \n (4) In the \"Enter the location\" textfield give the path alongwith the filename where the file should \n     be created.");
		frame.getContentPane().add(textArea);
		
		lblDirection = new JLabel("Direction:");
		lblDirection.setForeground(Color.RED);
		lblDirection.setBounds(448, 16, 69, 20);
		frame.getContentPane().add(lblDirection);
		
		label = new JLabel("Direction:");
		label.setForeground(Color.RED);
		label.setBounds(26, 385, 69, 20);
		frame.getContentPane().add(label);
	}
	
	private byte[] readFile(String filename){
		filename = "./src/" + filename + ".txt";
		String data = "";
		try {

		    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
		    String line;

		    while ((line = br.readLine()) != null) {
		        data += line;
		    }
		    br.close();

		} catch (IOException e) {
		    System.out.println("ERROR: unable to read file " + filename);
		    e.printStackTrace();   
		}
		
		System.out.println(data.length());
		return data.getBytes();
	}
}
